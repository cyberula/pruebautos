"use client"

import React from 'react'
import { useForm } from 'react-hook-form'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Form, FormControl, FormField, FormItem, FormLabel } from '@/components/ui/form'

interface BookingFormValues {
  name: string
  email: string
  telephone: string
  company: string
  car: string
  pickup: string
  return: string
  subject: string
  message: string
}

const BookingSection = () => {
  const form = useForm<BookingFormValues>({
    defaultValues: {
      name: '',
      email: '',
      telephone: '',
      company: '',
      car: '',
      pickup: '',
      return: '',
      subject: '',
      message: ''
    }
  })

  const onSubmit = (data: BookingFormValues) => {
    // In a real application, you'd handle the form submission here
    console.log('Form submitted', data)
    alert('Thank you for your inquiry. We will contact you shortly.')
    form.reset()
  }

  return (
    <div className="section section-gold">
      <div className="container">
        <h2 className="center" data-aos="fade-up" data-aos-offset="100">Booking</h2>

        <div className="form-holder" data-aos="fade-up" data-aos-offset="100">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="form-group">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="form-label">Name</FormLabel>
                      <FormControl>
                        <Input
                          className="form-control"
                          placeholder=""
                          {...field}
                          required
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="form-group">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="form-label">eMail</FormLabel>
                      <FormControl>
                        <Input
                          type="email"
                          className="form-control"
                          placeholder=""
                          {...field}
                          required
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="form-group">
                <FormField
                  control={form.control}
                  name="telephone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="form-label">Telephone</FormLabel>
                      <FormControl>
                        <Input
                          className="form-control"
                          placeholder=""
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="form-group">
                <FormField
                  control={form.control}
                  name="company"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="form-label">Company</FormLabel>
                      <FormControl>
                        <Input
                          className="form-control"
                          placeholder=""
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="form-group">
                <FormField
                  control={form.control}
                  name="car"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="form-label">Car</FormLabel>
                      <FormControl>
                        <Input
                          className="form-control"
                          placeholder=""
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="form-group">
                  <FormField
                    control={form.control}
                    name="pickup"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="form-label">Pickup</FormLabel>
                        <FormControl>
                          <Input
                            type="date"
                            className="form-control"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>

                <div className="form-group">
                  <FormField
                    control={form.control}
                    name="return"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="form-label">Return</FormLabel>
                        <FormControl>
                          <Input
                            type="date"
                            className="form-control"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="form-group">
                <FormField
                  control={form.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="form-label">Subject</FormLabel>
                      <FormControl>
                        <Input
                          className="form-control"
                          placeholder=""
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="form-group">
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="form-label">Message</FormLabel>
                      <FormControl>
                        <textarea
                          className="form-control"
                          rows={4}
                          placeholder=""
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="center">
                <Button type="submit" className="btn btn-white">
                  Send Inquiry
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  )
}

export default BookingSection
