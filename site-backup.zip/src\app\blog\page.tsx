"use client"

import React from 'react'
import Image from 'next/image'
import Link from 'next/link'
import Navigation from '@/components/Navigation'
import ContactSection from '@/components/ContactSection'

// Sample blog posts
const blogPosts = [
  {
    id: 'luxury-car-rental-in-monaco',
    title: 'The Ultimate Luxury Car Rental Experience in Monaco',
    excerpt: 'Discover why Monaco is the perfect destination for luxury car enthusiasts and how to make the most of your exotic car rental experience.',
    image: 'https://ext.same-assets.com/3094303499/1848624353.jpeg',
    date: 'March 15, 2024'
  },
  {
    id: 'monaco-grand-prix-2024',
    title: 'Monaco Grand Prix 2024: The Most Prestigious F1 Race',
    excerpt: 'Everything you need to know about attending the Monaco Grand Prix, the most glamorous event in the Formula 1 calendar.',
    image: 'https://ext.same-assets.com/3094303499/4124395302.jpeg',
    date: 'February 28, 2024'
  },
  {
    id: 'french-riviera-driving-routes',
    title: 'The Most Scenic Driving Routes on the French Riviera',
    excerpt: 'Explore the breathtaking coastal roads and mountain passes of the Côte d\'Azur in a luxury convertible.',
    image: 'https://ext.same-assets.com/3094303499/1885587757.jpeg',
    date: 'January 20, 2024'
  },
  {
    id: 'ferrari-vs-lamborghini',
    title: 'Ferrari vs Lamborghini: Which Should You Choose?',
    excerpt: 'A detailed comparison of these iconic Italian supercars to help you decide which matches your driving style and preferences.',
    image: 'https://ext.same-assets.com/3094303499/567837707.jpeg',
    date: 'December 10, 2023'
  }
]

export default function BlogPage() {
  return (
    <main className="overflow-x-hidden">
      <Navigation />

      {/* Banner Section */}
      <div
        className="banner-parallax"
        style={{ backgroundImage: 'url(https://ext.same-assets.com/3094303499/3164849637.jpeg)' }}
      >
        <div className="banner-inner-holder">
          <div className="banner-inner">
            <div className="title">
              <h1>Blog</h1>
            </div>
          </div>
        </div>
      </div>

      {/* Blog Posts */}
      <div className="section section-grey-dark">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {blogPosts.map((post) => (
              <div
                key={post.id}
                className="bg-secondary border border-gray-700 rounded-lg overflow-hidden shadow-lg"
                data-aos="fade-up"
                data-aos-offset="100"
              >
                <div className="relative h-64">
                  <Image
                    src={post.image}
                    alt={post.title}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <div className="text-primary text-sm mb-2">{post.date}</div>
                  <h3 className="text-white text-xl font-cinzel mb-3">{post.title}</h3>
                  <p className="text-gray-300 mb-4">{post.excerpt}</p>
                  <Link
                    href={`/blog/${post.id}`}
                    className="btn btn-gold inline-block"
                  >
                    Read More
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <section id="contact">
        <ContactSection />
      </section>
    </main>
  )
}
