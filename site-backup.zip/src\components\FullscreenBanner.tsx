"use client"

import React from 'react'

interface FullscreenBannerProps {
  backgroundImage: string
  title: string
}

const FullscreenBanner = ({ backgroundImage, title }: FullscreenBannerProps) => {
  const scrollToFleet = () => {
    const fleetSection = document.getElementById('fleet')
    if (fleetSection) {
      fleetSection.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <div
      className="banner-fullscreen-wrapper"
      style={{ backgroundImage: `url(${backgroundImage})` }}
    >
      <div className="banner-inner-holder">
        <div className="banner-inner">
          <div className="title" data-aos="fade-up" data-aos-offset="100">
            <div className="container">
              {title}
            </div>
            <br />
            <button
              onClick={scrollToFleet}
              className="btn btn-gold"
            >
              View Our Fleet
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default FullscreenBanner
