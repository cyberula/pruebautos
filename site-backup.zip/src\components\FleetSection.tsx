"use client"

import React from 'react'
import Image from 'next/image'
import Link from 'next/link'

const carCategories = [
  {
    id: 'exceptional-cars',
    title: 'Exceptional Cars',
    image: '/images/car-exceptional.png',
    link: '/luxury-cars/exceptional-cars'
  },
  {
    id: 'convertibles',
    title: 'Convertibles',
    image: '/images/car-convertible.png',
    link: '/luxury-cars/convertibles'
  },
  {
    id: 'luxury-sedans',
    title: 'Luxury Sedans',
    image: '/images/car-sedan.png',
    link: '/luxury-cars/luxury-sedans'
  },
  {
    id: 'suvs',
    title: 'SUVs',
    image: '/images/car-suv.png',
    link: '/luxury-cars/suvs'
  },
  {
    id: 'minivans',
    title: 'Minivans',
    image: '/images/car-minivan.png',
    link: '/luxury-cars/minivans'
  },
  {
    id: 'city-cars',
    title: 'City Cars',
    image: '/images/car-city.png',
    link: '/luxury-cars/city-cars'
  }
]

const FleetSection = () => {
  return (
    <div
      className="section section-grey-dark"
      id="latest-cars"
      style={{
        backgroundImage: "url(/images/latest-cars.jpeg)",
        backgroundPosition: "center",
        backgroundSize: "cover",
        backgroundBlendMode: "overlay",
        backgroundColor: "rgba(62, 66, 73, 0.9)"
      }}
    >
      <div className="container" data-aos="fade-up" data-aos-offset="100">
        <h2 className="center text-white">Latest Cars Collection</h2>
      </div>

      <div className="container">
        {carCategories.map((category, index) => (
          <React.Fragment key={category.id}>
            {index > 0 && <hr className="hr-dark" />}
            <div className="row align-items-center row-fleet" data-aos="fade-up" data-aos-offset="100">
              <div className="col-sm-8">
                <h4 className="text-white text-2xl mb-4">
                  <Link href={category.link} className="hover:text-primary">
                    {category.title}
                  </Link>
                </h4>
                <Link href={category.link} className="btn btn-gold" title={category.title}>
                  View
                </Link>
              </div>
              <div className="col-sm-4">
                <Link href={category.link}>
                  <Image
                    src={category.image}
                    alt={category.title}
                    width={200}
                    height={100}
                    className="car-sketch"
                  />
                </Link>
              </div>
            </div>
          </React.Fragment>
        ))}
        <hr className="hr-dark" />
      </div>
    </div>
  )
}

export default FleetSection
