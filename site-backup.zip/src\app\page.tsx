"use client"

// Main homepage component for Monte Carlo Sports Car website
import React from 'react'
import Image from 'next/image'
import Navigation from '@/components/Navigation'
import FullscreenVideo from '@/components/FullscreenVideo'
import FullscreenBanner from '@/components/FullscreenBanner'
import AboutSection from '@/components/AboutSection'
import FleetSection from '@/components/FleetSection'
import BookingSection from '@/components/BookingSection'
import ContactSection from '@/components/ContactSection'

export default function Home() {
  return (
    <main className="overflow-x-hidden">
      <Navigation />

      {/* Video Hero Section */}
      <section id="welcome" className="relative">
        <FullscreenVideo />
      </section>

      {/* Value Sections */}
      <section id="value1">
        <FullscreenBanner
          backgroundImage="/images/banner1.jpeg"
          title="In the heart of Monaco"
        />
      </section>

      <section id="value2">
        <FullscreenBanner
          backgroundImage="/images/banner2.jpeg"
          title="Selection of outstanding vehicles"
        />
      </section>

      <section id="value3">
        <FullscreenBanner
          backgroundImage="/images/banner3.jpeg"
          title="A personalized service 24/7"
        />
      </section>

      {/* About Section */}
      <section id="about">
        <AboutSection />
      </section>

      {/* Fleet Section */}
      <section id="fleet">
        <FleetSection />
      </section>

      {/* Booking Section */}
      <section id="booking">
        <BookingSection />
      </section>

      {/* Contact Section */}
      <section id="contact">
        <ContactSection />
      </section>
    </main>
  )
}
