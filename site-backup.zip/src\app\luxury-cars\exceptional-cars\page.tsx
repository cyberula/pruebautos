"use client"

import React from 'react'
import Image from 'next/image'
import Link from 'next/link'
import Navigation from '@/components/Navigation'
import BookingSection from '@/components/BookingSection'
import ContactSection from '@/components/ContactSection'

// Sample exceptional cars data
const exceptionalCars = [
  {
    id: 'lamborghini-revuelto',
    title: 'LAMBORGHINI REVUELTO',
    image: 'https://ext.same-assets.com/3094303499/1967059557.jpeg'
  },
  {
    id: 'lamborghini-huracan-evo-spyder',
    title: 'LAMBORGHINI HURACAN EVO SPYDER',
    image: 'https://ext.same-assets.com/3094303499/1610040679.jpeg'
  },
  {
    id: 'ferrari-812-gts',
    title: 'FERRARI 812 GTS',
    image: 'https://ext.same-assets.com/3094303499/637238515.jpeg'
  },
  {
    id: 'ferrari-purosangue',
    title: 'FERRARI PUROSANGUE',
    image: 'https://ext.same-assets.com/3094303499/654328659.jpeg'
  },
  {
    id: 'ferrari-296-gts',
    title: 'FERRARI 296 GTS',
    image: 'https://ext.same-assets.com/3094303499/4124395302.jpeg'
  },
  {
    id: 'ferrari-f8-spider',
    title: 'FERRARI F8 SPIDER',
    image: 'https://ext.same-assets.com/3094303499/567837707.jpeg'
  }
]

export default function ExceptionalCarsPage() {
  return (
    <main className="overflow-x-hidden">
      <Navigation />

      {/* Banner Section */}
      <div
        className="banner-parallax"
        style={{ backgroundImage: 'url(https://ext.same-assets.com/3094303499/1967059557.jpeg)' }}
      >
        <div className="banner-inner-holder">
          <div className="banner-inner">
            <div className="title">
              <h1>Exceptional Cars</h1>
            </div>
          </div>
        </div>
      </div>

      {/* Car Listings */}
      <div className="section section-grey-dark center">
        <div className="container">
          <Link href="/#latest-cars" className="btn btn-gold">
            Back to Fleet Overview
          </Link>

          <div className="row mt-12">
            {exceptionalCars.map((car) => (
              <div className="col-sm-6" key={car.id}>
                <div className="cursor-pointer">
                  <Image
                    src={car.image}
                    alt={car.title}
                    width={600}
                    height={400}
                    className="w-full h-64 object-cover"
                  />
                  <div className="box box-gold box-nomargin">
                    <h3 className="car-title">{car.title}</h3>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Booking Section */}
      <section id="booking">
        <BookingSection />
      </section>

      {/* Contact Section */}
      <section id="contact">
        <ContactSection />
      </section>
    </main>
  )
}
