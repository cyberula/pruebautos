"use client"

import React from 'react'
import Image from 'next/image'
import Link from 'next/link'

const ContactSection = () => {
  return (
    <div className="footer">
      <div className="container center">
        <h2 className="center" data-aos="fade-up" data-aos-offset="100">Contact</h2>

        <div data-aos="fade-up" data-aos-offset="100">
          1, Avenue Henry Dunant<br />
          MC 98000 Monaco<br />

          <a href="tel:+37799909330" className="text-white hover:text-primary">+377 99 90 93 30</a><br />
          <a href="mailto:contact@montecarlosportscar.com" className="text-white hover:text-primary">contact@montecarlosportscar.com</a><br /><br />
        </div>

        <div className="my-8">
          <Image
            src="/images/map-monaco.png"
            alt="Map Monaco"
            width={600}
            height={400}
            className="mx-auto rounded-md"
          />
        </div>

        <div className="mt-8 text-sm">
          Design by <a href="http://crevisio.com" className="text-primary hover:text-white" title="Crevisio Branding &amp; Photography Agency">Crevisio</a>
        </div>
      </div>
    </div>
  )
}

export default ContactSection
