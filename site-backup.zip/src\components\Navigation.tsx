"use client"

import React, { useState, useEffect } from 'react'
import Image from 'next/image'
import Link from 'next/link'

const Navigation = () => {
  const [menuOpen, setMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState('welcome')

  useEffect(() => {
    const handleScroll = () => {
      const sections = [
        'welcome', 'value1', 'value2', 'value3', 'about', 'fleet', 'booking', 'contact'
      ]

      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const rect = element.getBoundingClientRect()
          if (rect.top <= window.innerHeight / 2 && rect.bottom >= window.innerHeight / 2) {
            setActiveSection(section)
            break
          }
        }
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const toggleMenu = () => {
    setMenuOpen(!menuOpen)
  }

  const scrollToSection = (sectionId: string) => {
    const section = document.getElementById(sectionId)
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' })
    }
    if (menuOpen) {
      setMenuOpen(false)
    }
  }

  return (
    <>
      {/* Logo and Menu Button */}
      <div className="fixed top-0 left-0 w-full flex justify-between items-center p-4 z-50">
        <div className="logo z-50">
          <Link href="/">
            <Image
              src="/images/logo.png"
              alt="Monte Carlo Sports Car"
              width={160}
              height={60}
              className="h-auto"
            />
          </Link>
        </div>
        <div className="menu-button z-50">
          <button onClick={toggleMenu} className="bg-transparent border-none">
            <Image
              src="/images/menu-white.png"
              alt="Menu"
              width={30}
              height={30}
              className="h-auto cursor-pointer"
            />
          </button>
        </div>
      </div>

      {/* Gold Navigation Overlay */}
      <div
        className={`nav-gold ${menuOpen ? 'block' : 'hidden'}`}
      >
        <div className="nav-gold-holder">
          <div className="nav-gold-inner">
            <a
              onClick={() => scrollToSection('welcome')}
              className="nav-gold-link cursor-pointer"
            >
              Home
            </a>
            <a
              onClick={() => scrollToSection('about')}
              className="nav-gold-link cursor-pointer"
            >
              About
            </a>
            <a
              onClick={() => scrollToSection('fleet')}
              className="nav-gold-link cursor-pointer"
            >
              Fleet
            </a>
            <a
              onClick={() => scrollToSection('booking')}
              className="nav-gold-link cursor-pointer"
            >
              Booking
            </a>
            <Link href="/blog" className="nav-gold-link">
              Blog
            </Link>
            <a
              onClick={() => scrollToSection('contact')}
              className="nav-gold-link cursor-pointer"
            >
              Contact
            </a>
          </div>
        </div>
        <span className="nav-close" onClick={toggleMenu}>
          <Image
            src="/images/menu-white.png"
            alt="Close"
            width={30}
            height={30}
          />
        </span>
      </div>

      {/* Navigation Dots */}
      <div className="nav-buttons">
        <a
          onClick={() => scrollToSection('welcome')}
          className={`nav-button ${activeSection === 'welcome' ? 'active' : ''}`}
          id="nav-button-video"
        ></a>
        <a
          onClick={() => scrollToSection('value1')}
          className={`nav-button ${activeSection === 'value1' ? 'active' : ''}`}
          id="nav-button-value-1"
        ></a>
        <a
          onClick={() => scrollToSection('value2')}
          className={`nav-button ${activeSection === 'value2' ? 'active' : ''}`}
          id="nav-button-value-2"
        ></a>
        <a
          onClick={() => scrollToSection('value3')}
          className={`nav-button ${activeSection === 'value3' ? 'active' : ''}`}
          id="nav-button-value-3"
        ></a>
        <a
          onClick={() => scrollToSection('about')}
          className={`nav-button ${activeSection === 'about' ? 'active' : ''}`}
          id="nav-button-about"
        ></a>
        <a
          onClick={() => scrollToSection('fleet')}
          className={`nav-button ${activeSection === 'fleet' ? 'active' : ''}`}
          id="nav-button-fleet"
        ></a>
        <a
          onClick={() => scrollToSection('booking')}
          className={`nav-button ${activeSection === 'booking' ? 'active' : ''}`}
          id="nav-button-booking"
        ></a>
        <a
          onClick={() => scrollToSection('contact')}
          className={`nav-button ${activeSection === 'contact' ? 'active' : ''}`}
          id="nav-button-contact"
        ></a>
      </div>
    </>
  )
}

export default Navigation
