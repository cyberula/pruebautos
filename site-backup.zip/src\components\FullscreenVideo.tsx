"use client"

import React from 'react'
import Image from 'next/image'

const FullscreenVideo = () => {
  const scrollToNextSection = () => {
    const valueSection = document.getElementById('value1')
    if (valueSection) {
      valueSection.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <div className="video-background video-background-fullscreen">
      <video
        playsInline
        autoPlay
        muted
        loop
        id="bgvid"
      >
        <source src="/videos/background.mp4" type="video/mp4" />
      </video>

      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20">
        <div className="text-center">
          <Image
            src="/images/logo.png"
            alt="Monte Carlo Sports Car"
            width={300}
            height={100}
            className="mx-auto mb-2"
          />
          <p className="text-white text-xl font-light">Luxury Car Rental</p>
        </div>
      </div>

      <Image
        src="/images/scroll-arrow.png"
        alt="Scroll Down"
        width={40}
        height={40}
        className="scrollarrow cursor-pointer"
        onClick={scrollToNextSection}
      />
    </div>
  )
}

export default FullscreenVideo
