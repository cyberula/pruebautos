"use client"

import React from 'react'
import Image from 'next/image'
import Link from 'next/link'
import Navigation from '@/components/Navigation'
import BookingSection from '@/components/BookingSection'
import ContactSection from '@/components/ContactSection'

// Sample convertibles data
const convertibles = [
  {
    id: 'mini-cooper-s-convertible',
    title: 'MINI COOPER S CONVERTIBLE',
    image: 'https://ext.same-assets.com/3094303499/1756035444.jpeg'
  },
  {
    id: 'mini-cooper-convertible',
    title: 'MINI COOPER CONVERTIBLE',
    image: 'https://ext.same-assets.com/3094303499/4094062035.jpeg'
  },
  {
    id: 'mercedes-cle-cabriolet',
    title: 'MERCEDES CLE CABRIOLET',
    image: 'https://ext.same-assets.com/3094303499/47158920.jpeg'
  },
  {
    id: 'mercedes-e-class-convertible',
    title: 'MERCEDES E CLASS CONVERTIBLE',
    image: 'https://ext.same-assets.com/3094303499/4188486388.jpeg'
  },
  {
    id: 'mercedes-c-class-convertible',
    title: 'MERCEDES C CLASS CONVERTIBLE',
    image: 'https://ext.same-assets.com/3094303499/827618343.jpeg'
  },
  {
    id: 'bmw-series-4-convertible',
    title: 'BMW SERIE 4 CONVERTIBLE',
    image: 'https://ext.same-assets.com/3094303499/3039262524.jpeg'
  },
  {
    id: 'bmw-z4',
    title: 'BMW Z4',
    image: 'https://ext.same-assets.com/3094303499/1014571796.jpeg'
  },
  {
    id: 'porsche-718-boxster',
    title: 'PORSCHE 718 BOXSTER',
    image: 'https://ext.same-assets.com/3094303499/532322517.jpeg'
  }
]

export default function ConvertiblesPage() {
  return (
    <main className="overflow-x-hidden">
      <Navigation />

      {/* Banner Section */}
      <div
        className="banner-parallax"
        style={{ backgroundImage: 'url(https://ext.same-assets.com/3094303499/746820273.jpeg)' }}
      >
        <div className="banner-inner-holder">
          <div className="banner-inner">
            <div className="title">
              <h1>Convertibles</h1>
            </div>
          </div>
        </div>
      </div>

      {/* Car Listings */}
      <div className="section section-grey-dark center">
        <div className="container">
          <Link href="/#latest-cars" className="btn btn-gold">
            Back to Fleet Overview
          </Link>

          <div className="row mt-12">
            {convertibles.map((car) => (
              <div className="col-sm-6" key={car.id}>
                <div className="cursor-pointer">
                  <Image
                    src={car.image}
                    alt={car.title}
                    width={600}
                    height={400}
                    className="w-full h-64 object-cover"
                  />
                  <div className="box box-gold box-nomargin">
                    <h3 className="car-title">{car.title}</h3>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Booking Section */}
      <section id="booking">
        <BookingSection />
      </section>

      {/* Contact Section */}
      <section id="contact">
        <ContactSection />
      </section>
    </main>
  )
}
