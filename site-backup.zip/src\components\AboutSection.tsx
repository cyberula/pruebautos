"use client"

import React from 'react'
import Image from 'next/image'

const AboutSection = () => {
  return (
    <div className="section section-gold" id="section-about">
      <div className="container">
        <div data-aos="fade-up" data-aos-offset="100">
          <h2 className="center black">About Us</h2>
          <p>
            At <strong>MONTE CARLO SPORTS CAR</strong>, we boast extensive expertise in luxury cars, enabling us to meet the needs of the most demanding clientele. We offer a wide selection of outstanding vehicles, including the very latest models with our partnership with the best luxury brands, while also providing a personalized service in the French Riviera and throughout Europe. The car you drive can make your journey the most incredible experience.
          </p>

          <p>
            At <strong>MC SPORTS CAR</strong>, we make those experiences happen. Our customer services team is always happy to answer any questions and provide you with expert advice. They'll also help you to find the perfect vehicle, tailored to your needs & desires.
          </p>

          <div className="text-right">
            <Image
              src="/images/signature.png"
              alt="Signature"
              width={200}
              height={60}
              className="ml-auto"
            />
            <br />
            <span className="text-gray-700">Anthony Schmidt | General Manager</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AboutSection
